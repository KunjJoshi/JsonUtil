package parser;

public abstract class AbstractParser implements JsonParser {

}
